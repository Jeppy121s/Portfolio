package com.humber.Week4JDBCApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week4JdbcAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week4JdbcAppApplication.class, args);
	}

}
