INSERT INTO book(name,category,price)
    VALUES
    ('Harry Potter','JK Rowling',13),
    ('Final Fantasy 16','Naoki Yoshida',21),
    ('One Piece','Eichiro Oda',12),
    ('Danmachi','Fujino Omori',14);