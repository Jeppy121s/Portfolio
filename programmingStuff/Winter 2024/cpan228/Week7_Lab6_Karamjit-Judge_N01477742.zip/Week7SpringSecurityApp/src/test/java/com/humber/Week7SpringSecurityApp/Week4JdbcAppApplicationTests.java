package com.humber.Week7SpringSecurityApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week4JdbcAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
