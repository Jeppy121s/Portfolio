package com.humber.Week5JPAApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week5JPAAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week5JPAAppApplication.class, args);
	}

}
