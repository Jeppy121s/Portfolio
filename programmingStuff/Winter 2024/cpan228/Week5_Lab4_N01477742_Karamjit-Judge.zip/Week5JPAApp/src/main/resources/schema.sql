CREATE TABLE book(
    id int auto_increment,
    name varchar(20),
    category varchar(20),
    price double
);