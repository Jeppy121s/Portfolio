package com.humber.Project01_GameStore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project01GameStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(Project01GameStoreApplication.class, args);
	}

}
