//lab

import * as React from 'react';
import { useEffect, useState } from 'react';
import { Text, View, StyleSheet, FlatList, Button, RefreshControl } from 'react-native';
const API = 'https://random-data-api.com/api/v2/users?size=5';
const renderitem = ({ item }) => <Product first_name={item.first_name} last_name={item.last_name} email={item.email}/>;

const Product = (props) => (
  <View style={styles.item}>
    
    
    <Text style={styles.itemText}>name: {props.first_name} {props.last_name}</Text>
    <Text style={styles.itemText}>email: {props.email}</Text>

    
  </View>
);
    
    
export default function App() {

  const [data, setData] = useState([]);
  
  useEffect(() => {
    fetch(API)
    .then((response) => response.json())
    .then((json) => {setData(json);});
}, []);
    
return (

<View style={styles.container}>

  {/* <Text>Test</Text> */}
  <FlatList style={styles.productList}
  data={data}
   renderItem={renderitem}
   keyExtractor={(item) => item.id}/>
 <Button onPress={() => setRefetch} title="refresh page"/>
</View>

)
;

}

const styles = StyleSheet.create({
  productList:{alignContent:"stretch",width:"100%",},
  container: {flex: 1,justifyContent: 'center',  paddingTop: 40,  backgroundColor: '#ecf0f1',padding: 8,},
  item:{borderWidth:1,padding:10,margin:5,borderRadius:5,backgroundColor:"purple"},
  itemText:{color:"white"},
  image:{width:2}
});
















































//picker example
/*import * as React from 'react';
import {useState} from 'react';
import { Text, View, StyleSheet, } from 'react-native';
import {Picker} from '@react-native-picker/picker';
export default function App() {

    const [country, setCountry] = useState("Canada");
    
  return (   
     <View style={styles.container}> 
     <Text>You are from {country}</Text> 
     <Picker selectedValue={country} onValueChange={(value,index)=>{setCountry(value)}}>      
     <Picker.Item label="Canada" value="Canada" />        
     <Picker.Item label="United States" value="United States" />
     <Picker.Item label="Japan" value="Japan" />      
     </Picker>    
     </View>  );}
     
     const styles = StyleSheet.create({ 
       container: {    flex: 1,  
       justifyContent: 'center',    
       paddingTop: 30,    
       backgroundColor: '#ecf0f1',    
       padding: 8,  
},});*/

//status bar example
/*import { setStatusBarBackgroundColor } from 'expo-status-bar';
import React, { useState } from 'react';
import { Button, Platform, SafeAreaView, StatusBar, StyleSheet, Text, View } from 'react-native';
const Seperator = ()=>(
<View style={styles.seperator}></View>)

const App = () => {  
  const [hidden,setHidden] = useState(false);  
  const [barStyle,setbarStyle] = useState('light-content');  
  return (    <SafeAreaView style={styles.container}>      
  <StatusBar animated={true} backgroundColor="green" 
  barStyle={barStyle} showHideTransition={'fade'} hidden={hidden} />     
 <Button onPress={() => { setHidden(!hidden) }} title="Toggle Hidden" />     
  <Seperator />      
  <Button onPress={() => { setbarStyle('light-content') }} title="Set Bar Style to Light Content" />      
  <Seperator />      
  <Button onPress={() => { setbarStyle('dark-content') }} title="Set Bar Style to Dark Content" />      
  <Seperator />      
  
  <Button onPress={() => { setbarStyle('default') }} title="Set Bar Style to Default" />   
  <Seperator/>
  <Button onPress={() => { setStatusBarBackgroundColor('red') }} title="Set Bar Style to red"/>
   </SafeAreaView>  );};const styles = StyleSheet.create({  
    container: {
      flex: 1,height:400,padding:10,marginTop: StatusBar.currentHeight ,    
      backgroundColor: 'white',justifyContent:'flex-start'},seperator:{height:5}});
      
export default App;*/