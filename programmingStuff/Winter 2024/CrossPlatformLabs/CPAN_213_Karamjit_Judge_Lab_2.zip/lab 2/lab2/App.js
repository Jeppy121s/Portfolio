//import { StatusBar } from 'expo-statu s-bar';
import React from 'react';
import { StyleSheet, Text, View, TextInput } from 'react-native';

const registrationExample=()=>{
  const[name,onChangeTex]=React.useState("Karamjit");
  const[email,onChangeEmail]=React.useState("Example@gmail.com");
  const[number,onChangeNum]=React.useState("647-685-1234");
  
    return(
  <View style={{padding:50}}>
    <Text>{name}'s number is {number}</Text>
    <Text>Email: {email}</Text>

    <TextInput 
    style={styles.input}
    onChangeText={onChangeTex}
    value={name}
    placeholder='Name'
    />
  
    <TextInput
     style={styles.input}    
     onChangeText={onChangeNum}        
     value={number}       
      placeholder="Cell Phone"        
      keyboardType="numeric"
    />

  <TextInput
     style={styles.input}    
     onChangeText={onChangeEmail}        
     value={email}       
      placeholder="example@gmail.com"        
    />
  
  </View>
  
    );
  };
  export default registrationExample;
/*export default function App() {
  return (
    registrationExample
  );
}*/

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  input:{
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 12
  },
});

