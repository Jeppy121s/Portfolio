INSERT INTO book(name,category,price)
    VALUES
    ('Jacket','Champs',22),
    ('Running Shoes','Adidas',21),
    ('T-shirt','Adidas',21),
    ('Hat','Adidas',22);