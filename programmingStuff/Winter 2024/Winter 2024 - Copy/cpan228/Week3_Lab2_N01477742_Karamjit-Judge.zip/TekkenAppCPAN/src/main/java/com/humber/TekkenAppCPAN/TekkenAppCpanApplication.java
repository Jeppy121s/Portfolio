package com.humber.TekkenAppCPAN;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TekkenAppCpanApplication {

	public static void main(String[] args) {
		SpringApplication.run(TekkenAppCpanApplication.class, args);
	}

}
