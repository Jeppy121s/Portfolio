package com.example.Week12SpringProfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week12SpringProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
