package com.example.Week12SpringProfile.services;

public interface DBConfig {
    public String setUpDBConnection();

}
