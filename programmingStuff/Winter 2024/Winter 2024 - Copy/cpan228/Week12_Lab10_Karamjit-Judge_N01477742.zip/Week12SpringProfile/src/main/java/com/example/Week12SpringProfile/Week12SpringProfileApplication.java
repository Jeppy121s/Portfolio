package com.example.Week12SpringProfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week12SpringProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week12SpringProfileApplication.class, args);
	}

}
