package com.humber.cpan.Week1SpringProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week1SpringProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
