package com.humber.Project01_GameStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project01GameStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
